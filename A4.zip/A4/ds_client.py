# Starter code for assignment 3 in ICS 32 Programming with Software Libraries in Python

# Joana Ugarte
# joanau@uci.edu
# 44875730
import socket
import json
import ds_protocol 
import time
#import ui3


def writingJ(message, send, recv):
  send.write(json.dumps(message))
  send.flush()
  info = recv.readline()
  rec = ds_protocol.extract_json(info)
  print(rec.message)




def send(server:str, port:int, username:str, password:str, message:str, bio:str=None):
  '''
  The send function joins a ds server and sends a message, bio, or both

  :param server: The ip address for the ICS 32 DS server.
  :param port: The port where the ICS 32 DS server is accepting connections.
  :param username: The user name to be assigned to the message.
  :param password: The password associated with the username.
  :param message: The message to be sent to the server.
  :param bio: Optional, a bio for the user.
  '''

  counter = 0
  with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client:
    try:
      client.connect((server, port))
    except OSError:
      print("Error. Server not accessible.")
      exit()
    except ConnectionRefusedError:
      print("Connection refused.")
      exit()
      
    join = {"join": {"username": username, "password": password, "token": ""}}
    send = client.makefile('w')
    recv = client.makefile('r')

   
    send.write(json.dumps(join))
    send.flush()
    msg = json.loads(recv.readline())
    m = json.dumps(msg)
    data = ds_protocol.extract_json(m)
    
    if data[1] == 'Invalid password or username already taken':
      return data[1]
      

    if message == "" and bio == "":
      print(msg['response']['message'])
      if (msg['response']['type'] == 'error'):
        exit()

    if bio != "":
      token = msg['response']['token']
      bio = {"token": token, "bio": {"entry": bio ,"timestamp": time.time()}}
      writingJ(bio, send, recv)
      counter += 1
      
    if message != "":
      token = msg['response']['token']
      message = {"token": token, "post": {"entry": message,"timestamp": time.time()}}
      writingJ(message, send, recv)
      counter += 1


    if counter > 0:
      return True
    else:
      return False
    


